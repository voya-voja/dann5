#pragma once

#include <pybind11/pybind11.h>

#include <utility>
#include <Eigen/Dense>

#include <Qdef.h>
#include <Qops.h>

using namespace std;
using namespace Eigen;


namespace dann5 {
	namespace ocean {
		typedef auto_ptr<Qoperand> ApQoperand;
		typedef Matrix<Qoperand*, Dynamic, 1> Qoperands;

		class Qexpression : public Qoperands
		{
		public:
			class Add
			{
			private:
				OperandList mCarryForwards;

				Qaddition::Assignment mLastAssignment;
				bool mUseLastAssignmentCarryForward = false;

				Qoperand* construct(Qoperand*, Qoperand*);

			public:
				Add();
				~Add();

				// operator function () returns result operand by Add-ing left and right operand
				Qoperand* operator () (Qoperand*, Qoperand*);
				// operator function () returns result operand by Add-ing left and carry operands
				Qoperand* operator () (Qoperand*);
				// operator function () returns result operand by Add-ing carry operands
				Qoperand* operator () ();

				bool isCarryForward() const {return(!mCarryForwards.empty()); };
				bool isNeedCorretion() const { return(mLastAssignment.mpCarryForward != NULL); };
			};

			Qexpression();
			Qexpression(const Qexpression&);
			Qexpression(const Qdef&);
			~Qexpression();

			Qexpression operator *(const Qdef&) const;
			Qexpression& operator *=(const Qdef&);
			Qexpression operator *(const Qexpression&) const;
			Qexpression& operator *=(const Qexpression&);

			Qexpression operator +(const Qdef&) const;
			Qexpression& operator +=(const Qdef&);
			Qexpression operator +(const Qexpression&) const;
			Qexpression& operator +=(const Qexpression&);

			string toString() const;

			friend std::ostream& operator << (std::ostream&, const Qexpression&);
		protected:
			Qexpression(Index size);
			typedef Matrix<Qoperand*, Dynamic, Dynamic> Xmatrix;

			virtual Xmatrix thisX(const Qexpression&) const;
			virtual void sumDiagonals(const Xmatrix&);

		private:
		};
	};
};